﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'th', {
	options: 'ตัวเลือกไอคอนแสดงอารมณ์',
	title: 'แทรกสัญลักษณ์สื่ออารมณ์',
	toolbar: 'รูปสื่ออารมณ์'
} );
