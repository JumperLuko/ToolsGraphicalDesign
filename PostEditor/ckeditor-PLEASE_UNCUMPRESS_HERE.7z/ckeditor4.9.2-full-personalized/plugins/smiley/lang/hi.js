﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'hi', {
	options: 'Smiley Options', // MISSING
	title: 'स्माइली इन्सर्ट करें',
	toolbar: 'स्माइली'
} );
