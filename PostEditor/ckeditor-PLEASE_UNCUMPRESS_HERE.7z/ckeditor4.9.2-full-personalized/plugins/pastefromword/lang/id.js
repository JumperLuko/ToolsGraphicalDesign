﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'id', {
	confirmCleanup: 'Teks yang ingin anda tempel sepertinya di salin dari Word. Apakah anda mau membersihkannya sebelum menempel?',
	error: 'Tidak mungkin membersihkan data yang ditempel dikerenakan kesalahan internal',
	title: 'Tempel dari Word',
	toolbar: 'Tempel dari Word'
} );
