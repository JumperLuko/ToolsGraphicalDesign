﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'af', {
	confirmCleanup: 'Die teks wat u wil plak lyk asof dit uit Word gekopiëer is. Wil u dit eers skoonmaak voordat dit geplak word?',
	error: 'Die geplakte teks kon nie skoongemaak word nie, weens \'n interne fout',
	title: 'Plak vanuit Word',
	toolbar: 'Plak vanuit Word'
} );
