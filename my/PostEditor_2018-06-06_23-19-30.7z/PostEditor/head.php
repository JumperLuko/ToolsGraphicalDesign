<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="Sistema de postagem simplificado por JumperL">
    <meta name="author" content="Jumper_Luko, jumper.luko@gmail.com">
    <meta name="language" content="pt-br">
    <meta name="generator" content="Atom" />
    <meta name="revisit-after" content="7 days"/>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="responsive_flex.css">
</head>
