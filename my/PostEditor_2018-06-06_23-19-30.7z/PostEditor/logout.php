<?php
session_start();
session_unset();
session_destroy();
?>
<script>
    window.location='login.php#user', 0000
</script>
