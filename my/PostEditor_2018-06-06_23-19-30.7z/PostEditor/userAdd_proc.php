<?php
    // require('connect.php');
    // $sql = mysqli_query($conexao, "INSERT INTO `user` (`id_user`, `name_user`, `nickname_user`, `password_user`) VALUES ('1', 'Usuário Raiz', 'root', 'c14173849d7543f591683429af6bc22f55d1504f');");
 ?>
